
export const webRTCSingnaling={
    OFFER:"OFFER",
    ANSWER:"ANSWER",
    ICE_CANDIDATE:"ICE_CANDIDATE"
}